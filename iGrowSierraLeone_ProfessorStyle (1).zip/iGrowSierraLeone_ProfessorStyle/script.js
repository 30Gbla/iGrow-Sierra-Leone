/* iGrow Sierra Leone | Coursework 1 | JavaScript + jQuery interactions */
// Vanilla JavaScript: mobile menu, input keydown and live character counter.
const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');
menuToggle.addEventListener('click', function () {
    const opened = mainNav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(opened));
    menuToggle.textContent = opened ? '✕' : '☰';
});
mainNav.querySelectorAll('a').forEach(function (link) {
    link.addEventListener('click', function () {
        mainNav.classList.remove('open');
        menuToggle.setAttribute('aria-expanded', 'false');
        menuToggle.textContent = '☰';
    });
});
const message = document.getElementById('message');
const charCount = document.getElementById('charCount');
function updateCount() {
    const length = message.value.length;
    charCount.textContent = length + ' / 200 characters';
    charCount.classList.toggle('near-limit', length >= 180);
    charCount.style.fontWeight = 'normal';
}
message.addEventListener('input', updateCount);
// The coursework explicitly asks for an onkeydown interaction.
message.onkeydown = function () {
    // Show that the user is typing. The input event updates the actual count.
    charCount.style.fontWeight = 'bold';
};

// jQuery: document ready, selectors, click events, mouseover, animation and alerts.
$(document).ready(function () {
    function filterProducts() {
        const search = $('#productSearch').val().toLowerCase().trim();
        const category = $('.filter.active').attr('data-filter');
        let visible = 0;
        $('.product-card').each(function () {
            const matchesSearch = $(this).attr('data-search').indexOf(search) !== -1 || $(this).find('h3').text().toLowerCase().indexOf(search) !== -1;
            const matchesCategory = category === 'all' || $(this).attr('data-category') === category;
            if (matchesSearch && matchesCategory) { $(this).show(); visible++; }
            else { $(this).hide(); }
        });
        $('#noResults').prop('hidden', visible !== 0);
    }
    $('.filter').click(function () {
        $('.filter').removeClass('active');
        $(this).addClass('active');
        filterProducts();
    });
    $('#productSearch').on('input keydown', function () { filterProducts(); });
    // Mouseover changes the interface, as required in Coursework 1.
    $('.product-card').on('mouseover', function () { $(this).find('.product-link').css('color', '#b58024'); });
    $('.product-card').on('mouseout', function () { $(this).find('.product-link').css('color', ''); });
    // Selecting a product pre-fills the contact form's message.
    $('.product-link').click(function () {
        const product = $(this).attr('data-product');
        $('#interest').val(product === 'Farming Equipment' ? 'Agricultural equipment' : 'Buying produce');
        $('#message').val('Hello, I would like to learn more about ' + product + '.');
        updateCount();
        $('#formFeedback').text('Your enquiry is ready to complete below.');
        $('.form-card').hide().fadeIn(450);
    });
    // Form submission: HTML5 validation runs before this event.
    $('#contactForm').submit(function (event) {
        event.preventDefault();
        const name = $('#fullName').val().trim();
        const phone = $('#telephone').val().trim();
        if (!/^[0-9]{8}$/.test(phone)) {
            window.alert('Please enter exactly 8 telephone digits.');
            $('#telephone').focus();
            return;
        }
        $('#formFeedback').text('Thank you, ' + name + '! Your enquiry has been validated in this demonstration. No message has been sent.');
        window.alert('Thank you, ' + name + '! This is a demonstration: your enquiry was not sent to a server.');
    });
    $('#contactForm').on('reset', function () {
        $('#formFeedback').text('');
        setTimeout(updateCount, 0);
    });
});
