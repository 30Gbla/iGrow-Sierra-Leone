iGrow Sierra Leone — CSE213 Coursework 1 (Reviewed)
====================================================

OPENING THE WEBSITE
1. Right-click the ZIP and select Extract All.
2. Open the extracted iGrowSierraLeone_Coursework1_Reviewed folder.
3. Double-click index.html. Do not open index.html inside the ZIP.
4. Keep style.css, script.js, jquery.min.js and images/ together.

FILES
index.html     HTML5 page, navigation, articles, images, list, table, form
style.css      CSS3 layout, backgrounds, typography, media queries
script.js      JavaScript events, message counter, jQuery interactions
jquery.min.js  Local jQuery library
images/        Local image assets used by the page

COURSEWORK REQUIREMENTS
- HTML5: headings, paragraphs, articles, links, images, buttons, lists, table
- CSS3: fonts, colors, background image, borders, box model, responsive rules
- Navigation: seven working in-page section links
- Form: name, email, 8-digit telephone, message (200 characters max)
- JavaScript: live counter and keydown interaction
- jQuery: product filtering, mouseover effects, fade animation, alert feedback

MANUAL TESTS
- Open on desktop and resize to tablet and phone widths.
- Click all navigation links and the mobile menu.
- Search for rice; select Export crops; reset to All products.
- Enter 200 characters in the message field and try a 201st.
- Try an invalid email and telephone number; then submit valid details.
- Hover over a marketplace card and click Enquire.

IMPORTANT LIMITATIONS
This is a front-end coursework demonstration, not a deployed marketplace.
The contact form does not send emails or store information on a server.
Account registration, escrow, real payments and real listings are not provided.
Images are illustrative and do not verify specific farms or sellers.
Please review the content, explain the code in your own words and comply
with your university's rules on individual work and AI assistance.

CSS STYLE REVIEW
The CSS is formatted like the professor's Week 3 example solutions: comments, readable selectors and one declaration per line. Colors previously stored in variables are written directly in each rule. The layout still uses Flexbox/Grid and responsive media queries to meet the assignment and preserve the existing design. This is not a verbatim copy of the professor's example code.

Study the HTML, CSS and JavaScript before submitting; do not misrepresent assistance or claim you wrote code that you did not write.
